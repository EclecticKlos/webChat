$( document ).ready(function() {
console.log("THIS RAN")
console.log("*" * 100)
  
});

